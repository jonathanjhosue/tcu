tinyMCE.addI18n('en.youtube',{
	desc : 'Insert YouTube video'
});
