tinyMCE.addI18n('en.youtube_dlg',{
    title : "YouTube Video",
    instr : "Insert the YouTube video ID of the video you want to appear.",
    ytID : "ID",
    ytW : "Width",
    ytH : "Height"
});