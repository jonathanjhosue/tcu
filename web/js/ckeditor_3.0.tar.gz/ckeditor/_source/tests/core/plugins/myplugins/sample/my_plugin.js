﻿CKEDITOR.plugins.add( 'myplugin' , {
	definition :  true
} );
