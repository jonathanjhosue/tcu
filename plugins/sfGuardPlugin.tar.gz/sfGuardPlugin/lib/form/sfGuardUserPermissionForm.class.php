<?php

/**
 * sfGuardUserPermission form.
 *
 * @package    form
 * @subpackage sf_guard_user_permission
 * @version    SVN: $Id: sfGuardUserPermissionForm.class.php 9999 2008-06-29 21:24:44Z fabien $
 */
class sfGuardUserPermissionForm extends BasesfGuardUserPermissionForm
{
  public function configure()
  {
  }
}
