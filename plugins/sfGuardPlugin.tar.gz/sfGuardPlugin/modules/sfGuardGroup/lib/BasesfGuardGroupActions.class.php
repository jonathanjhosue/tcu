<?php

require_once dirname(__FILE__).'/sfGuardGroupGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/sfGuardGroupGeneratorHelper.class.php';

/**
 * sfGuardGroup actions.
 *
 * @package    sfGuardPlugin
 * @subpackage sfGuardGroup
 * @author     Fabien Potencier
 * @version    SVN: $Id: BasesfGuardGroupActions.class.php 12965 2008-11-13 06:02:38Z fabien $
 */
class BasesfGuardGroupActions extends autosfGuardGroupActions
{
}
