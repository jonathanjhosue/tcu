<?php

require_once dirname(__FILE__).'/../lib/BasesfGuardGroupActions.class.php';

/**
 * sfGuardGroup actions.
 *
 * @package    sfGuardPlugin
 * @subpackage sfGuardGroup
 * @author     Fabien Potencier
 * @version    SVN: $Id: actions.class.php 12965 2008-11-13 06:02:38Z fabien $
 */
class sfGuardGroupActions extends BasesfGuardGroupActions
{
}
