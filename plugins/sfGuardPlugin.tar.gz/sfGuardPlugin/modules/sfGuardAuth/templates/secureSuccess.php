
<?php use_helper('I18N') ?>

<p><?php echo __("No tienes permiso para acceder a esta sección.") ?></p>
